--------------------------------------------------------
--  File created - Sunday-March-25-2018   
--------------------------------------------------------
DROP TRIGGER "VENKATESH"."CANDIDATE_UPDATE_OPERATIONS";
DROP TRIGGER "VENKATESH"."CANDIDATE_INSERT_OPERATIONS";
--------------------------------------------------------
--  DDL for Table CANDIDATE
--------------------------------------------------------

  CREATE TABLE "VENKATESH"."CANDIDATE" 
   (	"IDENTIFICATION_NO" NUMBER(10,0), 
	"FIRST_NAME" VARCHAR2(20 BYTE), 
	"MIDDLE_NAME" VARCHAR2(20 BYTE), 
	"LAST_NAME" VARCHAR2(20 BYTE), 
	"FULL_NAME" VARCHAR2(70 BYTE), 
	"DATE_OF_BIRTH" DATE, 
	"COUNTRY" NUMBER(30,0), 
	"STATE" NUMBER(30,0), 
	"CITY" NUMBER(30,0), 
	"ADDRESS" VARCHAR2(100 BYTE), 
	"MOBILE_NO" NUMBER(30,0), 
	"PROFILE" BLOB, 
	"RESUME" BLOB, 
	"CREATED_ON" TIMESTAMP (6), 
	"MODIFIED_ON" TIMESTAMP (6), 
	"CANDIDATE_ID" VARCHAR2(10 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" 
 LOB ("PROFILE") STORE AS BASICFILE (
  TABLESPACE "SYSTEM" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE LOGGING 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB ("RESUME") STORE AS BASICFILE (
  TABLESPACE "SYSTEM" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE LOGGING 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

   COMMENT ON COLUMN "VENKATESH"."CANDIDATE"."IDENTIFICATION_NO" IS 'Unique Identification Number';
   COMMENT ON COLUMN "VENKATESH"."CANDIDATE"."FIRST_NAME" IS 'First Name';
   COMMENT ON COLUMN "VENKATESH"."CANDIDATE"."MIDDLE_NAME" IS 'Middle Name';
   COMMENT ON COLUMN "VENKATESH"."CANDIDATE"."LAST_NAME" IS 'Last Name';
   COMMENT ON COLUMN "VENKATESH"."CANDIDATE"."FULL_NAME" IS 'Full Name';
   COMMENT ON COLUMN "VENKATESH"."CANDIDATE"."CANDIDATE_ID" IS 'Candidate ID';
--------------------------------------------------------
--  DDL for Trigger CANDIDATE_UPDATE_OPERATIONS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "VENKATESH"."CANDIDATE_UPDATE_OPERATIONS" BEFORE
   UPDATE OF first_name,full_name,last_name,middle_name,modified_on,city ON candidate
    FOR EACH ROW
BEGIN
    :new.modified_on := SYSDATE;
    :new.full_name := generate_full_name(:new.first_name,:new.middle_name,:new.last_name);

    :new.state := get_candidate_state_id(:new.city);
    :new.country := get_candidate_country_id(:new.city);
END;
/
ALTER TRIGGER "VENKATESH"."CANDIDATE_UPDATE_OPERATIONS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger CANDIDATE_INSERT_OPERATIONS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "VENKATESH"."CANDIDATE_INSERT_OPERATIONS" BEFORE
    INSERT ON candidate
    FOR EACH ROW
BEGIN
    :new.created_on := SYSDATE;
    :new.modified_on := SYSDATE;
    :new.full_name := generate_full_name(:new.first_name,:new.middle_name,:new.last_name);

    :new.state := get_candidate_state_id(:new.city);
    :new.country := get_candidate_country_id(:new.city);
    :new.candidate_id := substr(:new.first_name,0,1)
    || substr(:new.last_name,0,1)
    || substr(:new.identification_no,-5);

END;
/
ALTER TRIGGER "VENKATESH"."CANDIDATE_INSERT_OPERATIONS" ENABLE;
--------------------------------------------------------
--  DDL for Function GENERATE_FULL_NAME
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GENERATE_FULL_NAME" 
(
  FIRST_NAME IN VARCHAR2 
, MIDDLE_NAME IN VARCHAR2 
, LAST_NAME IN VARCHAR2 
) RETURN VARCHAR2 AS 
BEGIN

 RETURN  TRIM(LAST_NAME || ', ' || FIRST_NAME || ' ' || MIDDLE_NAME);

END GENERATE_FULL_NAME;

/
--------------------------------------------------------
--  DDL for Function GET_CANDIDATE_COUNTRY_ID
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GET_CANDIDATE_COUNTRY_ID" (
    candidate_city IN NUMBER
) RETURN NUMBER AS
    candidate_country_id   NUMBER(30);
BEGIN
    SELECT
        country_id
    INTO
        candidate_country_id
    FROM
        country
    WHERE
        country_id = (
            SELECT
                country
            FROM
                state
            WHERE
                state_id = (
                    SELECT
                        state
                    FROM
                        city
                    WHERE
                        city_id = candidate_city
                )
        );

    RETURN candidate_country_id;
END get_candidate_country_id;

/
--------------------------------------------------------
--  DDL for Function GET_CANDIDATE_STATE_ID
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GET_CANDIDATE_STATE_ID" (
    candidate_city IN NUMBER
) RETURN NUMBER AS
    candidate_state_id   NUMBER(30);
BEGIN
    SELECT
        state_id
    INTO
        candidate_state_id
    FROM
        state
    WHERE
        state_id = (
            SELECT
                state
            FROM
                city
            WHERE
                city_id = candidate_city
        );

    RETURN candidate_state_id;
END get_candidate_state_id;

/
