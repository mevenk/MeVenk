--------------------------------------------------------
--  File created - Sunday-March-25-2018   
--------------------------------------------------------
DROP FUNCTION "VENKATESH"."GENERATE_FULL_NAME";
DROP FUNCTION "VENKATESH"."GET_CANDIDATE_COUNTRY";
DROP FUNCTION "VENKATESH"."GET_CANDIDATE_COUNTRY_ID";
DROP FUNCTION "VENKATESH"."GET_CANDIDATE_STATE";
DROP FUNCTION "VENKATESH"."GET_CANDIDATE_STATE_ID";
--------------------------------------------------------
--  DDL for Table CITY
--------------------------------------------------------

  CREATE TABLE "VENKATESH"."CITY" 
   (	"CITY_ID" NUMBER(30,0), 
	"CITY_NAME" VARCHAR2(50 BYTE), 
	"STATE" NUMBER(30,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table COUNTRY
--------------------------------------------------------

  CREATE TABLE "VENKATESH"."COUNTRY" 
   (	"COUNTRY_ID" NUMBER(30,0), 
	"COUNTRY_NAME" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table STATE
--------------------------------------------------------

  CREATE TABLE "VENKATESH"."STATE" 
   (	"STATE_ID" NUMBER(30,0), 
	"STATE_NAME" VARCHAR2(50 BYTE), 
	"COUNTRY" NUMBER(30,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Function GENERATE_FULL_NAME
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GENERATE_FULL_NAME" 
(
  FIRST_NAME IN VARCHAR2 
, MIDDLE_NAME IN VARCHAR2 
, LAST_NAME IN VARCHAR2 
) RETURN VARCHAR2 AS 
BEGIN

 RETURN  TRIM(LAST_NAME || ', ' || FIRST_NAME || ' ' || MIDDLE_NAME);

END GENERATE_FULL_NAME;

/
--------------------------------------------------------
--  DDL for Function GET_CANDIDATE_COUNTRY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GET_CANDIDATE_COUNTRY" (
    candidate_city IN NUMBER
) RETURN VARCHAR2 AS
    candidate_country_name   VARCHAR2(50);
BEGIN
    SELECT
        country_name
    INTO
        candidate_country_name
    FROM
        country
    WHERE
        country_id = (
            SELECT
                country
            FROM
                state
            WHERE
                state_id = (
                    SELECT
                        state
                    FROM
                        city
                    WHERE
                        city_id = candidate_city
                )
        );

    RETURN candidate_country_name;
END get_candidate_country;

/
--------------------------------------------------------
--  DDL for Function GET_CANDIDATE_COUNTRY_ID
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GET_CANDIDATE_COUNTRY_ID" (
    candidate_city IN NUMBER
) RETURN NUMBER AS
    candidate_country_id   NUMBER(30);
BEGIN
    SELECT
        country_id
    INTO
        candidate_country_id
    FROM
        country
    WHERE
        country_id = (
            SELECT
                country
            FROM
                state
            WHERE
                state_id = (
                    SELECT
                        state
                    FROM
                        city
                    WHERE
                        city_id = candidate_city
                )
        );

    RETURN candidate_country_id;
END get_candidate_country_id;

/
--------------------------------------------------------
--  DDL for Function GET_CANDIDATE_STATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GET_CANDIDATE_STATE" (
    candidate_city IN NUMBER
) RETURN VARCHAR2 AS
    candidate_state_name   VARCHAR2(50);
BEGIN
    SELECT
        state_name
    INTO
        candidate_state_name
    FROM
        state
    WHERE
        state_id = (
            SELECT
                state
            FROM
                city
            WHERE
                city_id = candidate_city
        );

    RETURN candidate_state_name;
END get_candidate_state;

/
--------------------------------------------------------
--  DDL for Function GET_CANDIDATE_STATE_ID
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENKATESH"."GET_CANDIDATE_STATE_ID" (
    candidate_city IN NUMBER
) RETURN NUMBER AS
    candidate_state_id   NUMBER(30);
BEGIN
    SELECT
        state_id
    INTO
        candidate_state_id
    FROM
        state
    WHERE
        state_id = (
            SELECT
                state
            FROM
                city
            WHERE
                city_id = candidate_city
        );

    RETURN candidate_state_id;
END get_candidate_state_id;

/
