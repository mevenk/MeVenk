--------------------------------------------------------
--  File created - Sunday-March-25-2018   
--------------------------------------------------------
DROP SEQUENCE "MEVENK"."CITY_ID_SEQ";
DROP SEQUENCE "MEVENK"."COUNTRY_ID_SEQ";
DROP SEQUENCE "MEVENK"."IDENTIFICATION_NUMBER_SEQ";
DROP SEQUENCE "MEVENK"."STATE_ID_SEQ";
--------------------------------------------------------
--  DDL for Sequence CITY_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "MEVENK"."CITY_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1001 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COUNTRY_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "MEVENK"."COUNTRY_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1001 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence IDENTIFICATION_NUMBER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "MEVENK"."IDENTIFICATION_NUMBER_SEQ"  MINVALUE 1000000001 MAXVALUE 9999999999 INCREMENT BY 1 START WITH 1000000037 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STATE_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "MEVENK"."STATE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1001 CACHE 20 NOORDER  NOCYCLE ;
